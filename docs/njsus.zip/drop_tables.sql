drop table TOWN CASCADE;
drop table RESTAURANT CASCADE;
drop table VEGAN_OPTIONS;
drop table SUSTAINABILITY;
